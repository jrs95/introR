##### Intro to R practical #####

## 1: Setting the working directory
# Use setwd to set the working directory

setwd("C:/User/user/Documents")

## 2: Open dataset
# Use read.csv to open the lbw dataset

lbw  <- read.csv("lbw.csv") 

## 3: Get variable names and values
# Use the names function to get the variable names
# Use $ and [,] to output the birthweight variable 

names(lbw) 
lbw$bwt 
lbw[, "bwt"]

## 4: Create a new variable
# Use $ and < to a T/F variable for very low birthweight 

lbw$vlow <- lbw$bwt < 1500 
names(lbw)
head(lbw)

## 5: Summarise continuous variables
# Use the commands below to summarise age

mean(lbw$age)
sd(lbw$age)
median(lbw$age) 
IQR(lbw$age) 
mad(lbw$age) 
min(lbw$age) 
max(lbw$age) 
range(lbw$age) 
summary(lbw$age) 

mean(lbw$age[lbw$bwt<2500])
sd(lbw$age[lbw$bwt<2500]) 

mean(lbw$age[lbw$low==1])
sd(lbw$age[lbw$low==1]) 

## 6: Correlation
# Use the cor command to calculate the correlation between birthweight, maternal weight and age

cor(lbw$lwt, lbw$bwt)
cor(lbw$age, lbw$bwt)
cor(lbw$lwt, lbw$age)

## 7: Summarise categorical variables
# Use table to summarise premature labour history, maternal smoking and history of hypertension

table(lbw$ptl)
table(lbw$ptl, lbw$smoke) 
ptl_smoke <- table(lbw$ptl, lbw$smoke) 
table(lbw[,c("ptl", "smoke", "ht")])

## 8: Marginal totals and proportion tables
# Use addmargins to add marginal totals and prop.table to present proportions instead of frequencies for the table summarising premature labour history and maternal smoking

addmargins(ptl_smoke) 
prop.table(ptl_smoke, 1) 
prop.table(ptl_smoke, 2) 
prop.table(ptl_smoke) 

## 9: Plots
# Use the basic plotting tools to plot the relationship between birthweight and maternal weight as well as the distribution of age

plot(lbw$bwt, lbw$lwt)
hist(lbw$age) 
boxplot(lbw$age) 

## 10: Linear regresion
# Regress birthweight on maternal weight

lm(bwt ~ lwt, data=lbw) 
model <- lm(bwt ~ lwt, data=lbw) 
summary(model) 
names(model) 
